<div class="row">
    <!--div class="col-md-12"><h3><?php echo ucfirst($settings->client);?> Assigned</h3></div>
    <div class="clearfix"></div-->

    <div class="col-md-12">
        <!-- BEGIN Portlet PORTLET-->
        <div class="portlet box green-meadow">
            <div class="portlet-title">
                <div class="caption">
                    <i class="icon-globe"></i><?php echo ucfirst($settings->client);?> / Challenger
                </div>
                <!--div class="tools">
                    <a href="javascript:;" class="collapse" data-original-title="" title="">
                    </a>
                    <a href="#portlet-config" data-toggle="modal" class="config" data-original-title="" title="">
                    </a>
                    <a href="" class="fullscreen" data-original-title="" title="">
                    </a>
                    <a href="javascript:;" class="reload" data-original-title="" title="">
                    </a>
                </div-->
            </div>
            <div class="portlet-body">
                <div class="col-sm-3">
                    <img class="jobimg" src="<?php echo $this->request->webroot;?>img/logos/MEELogo.png" />
                </div>
                <div class="col-sm-9">

                    Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Cras mattis consectetur purus sit amet fermentum. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.
                    Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Cras mattis consectetur purus sit amet fermentum. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.


                    <div class="clearfix text-right margin-top-20">
                        <button type="button" class="btn default">View</button>
                        <button type="button" class="btn yellow">Edit</button>
                        <button type="button" class="btn green">Upload</button>
                        <button type="button" class="btn red">Delete</button>
                        <button type="button" class="btn blue">Project Board</button>
                        <button type="button" class="btn purple">Deployment</button>
                    </div>

                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <!-- END Portlet PORTLET-->
    </div>
    </div>