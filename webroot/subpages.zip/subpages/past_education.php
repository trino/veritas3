<div id="toremove"><div class="table-scrollable">
    <table class="table table-striped">
                <tr><th colspan="2">Past Education</th></tr>
                <tr><td colspan="2">School/College Name<input type="text" class="form-control" name="college_school_name[]" /></td>
                </tr>
                <tr><td colspan="2">Address<input type="text" class="form-control" name="address[]" /></td></tr>
                <tr><td>Supervisor's Name:<input type="text" class="form-control" name="supervisior_name[]"/></td>
                <td>Phone #:<input type="text" class="form-control" name="supervisior_phone[]"/></td></tr>
                <tr><td>Supervisor's Email:<input type="text" class="form-control" name="supervisior_email[]" /></td>
                <td>Secondary Email:<input type="text" class="form-control" name="supervisior_secondary_email[]"/></td></tr>
                <tr><td>Education Start Date:<input type="text" class="form-control" name="education_start_date[]" /></td>
                <td>Education End Date:<input type="text" class="form-control" name="education_end_date[]"/></td></tr>
                <tr><td>Claims with this Tutor:&nbsp;&nbsp;<input type="radio" name="claim_tutor[]" value="1" />&nbsp;&nbsp;Yes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="claim_tutor[]" value="0" />&nbsp;&nbsp;&nbsp;&nbsp;No</td>
                <td>Date Claims Occured:<input type="text" class="form-control" name="date_claims_occur[]" /></td></tr>
                <tr><td colspan="2">Education history confirmed by (Verifier Use Only):<input type="text" class="form-control" name="education_history_confirmed_by[]" /></td></tr>
                <tr><td>Signature:<input type="text" class="form-control" name="signature[]" /></td>
                <td>Date/Time:<input type="text" class="form-control" name="date_time[]" /></td></tr>
                
    </table>
</div>
<div class="delete">
    <a href="javascript:void(0);" class="btn red" id="delete">Delete</a>
</div>
  </div>  



 