<!--div class="todo-tasklist">
    <div class="todo-tasklist-item todo-tasklist-item-border-green">

        <div class="todo-tasklist-item-title"><h2> Success!</h2> </div>
        <div class="todo-tasklist-item-text"><h4> Your order has been submitted. You will be notified once your order is processed. <br />

        <div class="todo-tasklist-controls pull-left">

        </div>
    </div>
</div


<div class="note note-success blockmsg">
    <h4 class="block">Your Order Has Been Submitted!</h4>
    <p>
        You will be notified once it's processed.
    </p>
  You will be redirected to dashboard in <span class="seconds"><strong>10</strong></span> seconds. 
</div>-->
