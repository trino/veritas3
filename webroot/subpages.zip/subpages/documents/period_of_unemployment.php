<?php
 if($_SERVER['SERVER_NAME'] =='localhost'){ echo "<span style ='color:red;'>subpages/documents/period_of_unemployment.php #INC147</span>"; }
 ?>
<div>
<div class="form-group col-md-12">
                <label class="control-label col-md-5">Period Of Unemployment(if any) From:</label>
                <div class="col-md-3">
					<input type="text" class="form-control"/>
                </div>
                <label class="control-label col-md-1">To:</label>
                <div class="col-md-3">
					<input type="text" class="form-control"/>
                </div>
            </div>
            
            <div class="form-group col-md-12">
				<label class="control-label col-md-3">Employer : </label>
				<div class="col-md-9">
					<input type="text" class="form-control"/>
				</div>
            </div>
            
            
            
            <div class="form-group col-md-12">
                <label class="control-label col-md-3">Address : </label>
                <div class="col-md-3">
					<input type="text" class="form-control" placeholder="City"/>
				</div>
                <div class="col-md-3">
					<input type="text" class="form-control" placeholder="Province"/>
				</div>
                <div class="col-md-3">
					<input type="text" class="form-control" placeholder="Postal Code"/>
				</div>
			</div>
            
            <div class="form-group col-md-12">
                <label class="control-label col-md-3">Dates : From </label>
				<div class="col-md-3">
					<input type="text" class="form-control date-picker" placeholder="YYYY-MM-DD"/>
				</div>
                <label class="control-label col-md-3">To </label>
				<div class="col-md-3">
					<input type="text" class="form-control date-picker" placeholder="YYYY-MM-DD"/>
				</div>
            </div>
            
            <div class="form-group col-md-12">
                <label class="control-label col-md-3">Phone Number : </label>
                <div class="col-md-3">
					<input type="text" class="form-control"/>
				</div>
                <label class="control-label col-md-3">Position Held : </label>
                <div class="col-md-3">
					<input type="text" class="form-control"/>
				</div>
            </div>
            
            <div class="form-group col-md-12">
                <label class="control-label col-md-3">Reason for Leaving : </label>
                <div class="col-md-9">
					<textarea class="form-control"></textarea>
				</div>
            </div>
            
            <div class="form-group col-md-12">
                <label class="control-label col-md-3">Equipment Operated : </label>
                <div class="col-md-6">
					<input type="checkbox"/>&nbsp;Vans&nbsp;
                    <input type="checkbox"/>&nbsp;Reefers&nbsp;
                    <input type="checkbox"/>&nbsp;Decks&nbsp;
                    <input type="checkbox"/>&nbsp;Super B's&nbsp;
                    <input type="checkbox"/>&nbsp;Straight Truck&nbsp;
                    <input type="checkbox"/>&nbsp;Others:
                    </div>
                    <div class="col-md-3"><input type="text" class="form-control" />
                    </div>
            </div>
            
            <div class="form-group col-md-12">
                <label class="control-label col-md-3">Driving Experience : </label>
                <div class="col-md-6">
					<input type="checkbox"/>&nbsp;Local&nbsp;
                    <input type="checkbox"/>&nbsp;Canada&nbsp;
                    <input type="checkbox"/>&nbsp;Canada : Rocky Mountains&nbsp;
                    <input type="checkbox"/>&nbsp;USA&nbsp;
                    </div>
            </div>
            
            <div class="form-group col-md-12">
                <label class="control-label col-md-10">Was your job designated as a safety-sensitive function in any DOT-regulated mode subject to drug and alcohol testing requirements of 49 CFR Part 40?</label>
                <div class="col-md-2">
					<input type="radio"/>&nbsp;Yes&nbsp;
                    <input type="radio"/>&nbsp;No&nbsp;
                </div>
            </div>
            
            <a href="javascript:void(0);" class="delete_form btn red">Delete</a>
            <div class="clearfix"></div>
            <hr/>
          </div>