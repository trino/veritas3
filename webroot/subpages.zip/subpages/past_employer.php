<div id="toremove"><div class="table-scrollable">
    <table class="table table-striped">
                <tr><th colspan="2">Past Employer</th></tr>
                <tr><td colspan="2">Company Name<input name="company_name[]" type="text" class="form-control" /></td></tr>
                <tr>
                    <td>Address<input name="address[]" type="text" class="form-control" /></td>
                    <td>City<input type="text" class="form-control" name="city[]" /></td>
                </tr>
                <tr>
                    <td>State/Province<input type="text" class="form-control" name="state_province[]" /></td>
                    <td>Country<input type="text" class="form-control" name="country[]" /></td>
                </tr>

                <tr><td>Supervisor's Name:<input name="supervisor_name[]" type="text" class="form-control"/></td>
                <td>Phone #:<input name="supervisor_phone[]" type="text" class="form-control"/></td></tr>
                <tr><td>Supervisor's Email:<input name="supervisor_email[]" type="text" class="form-control"/></td>
                <td>Secondary Email:<input name="supervisor_secondary_email[]" type="text" class="form-control"/></td></tr>
                <tr><td>Employment Start Date:<input name="employment_start_date[]" type="text" class="form-control"/></td>
                <td>Employment End Date:<input name="employment_end_date[]" type="text" class="form-control"/></td></tr>
                <tr><td>Claims with this Employer:&nbsp;&nbsp;<input name="claims_with_employer[]" value="1" type="radio"/>&nbsp;&nbsp;Yes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="claims_with_employer[]" value="0" type="radio"/>&nbsp;&nbsp;&nbsp;&nbsp;No</td>
                <td>Date Claims Occured:<input name="claims_recovery_date[]" type="text" class="form-control"/></td></tr>
                <tr><td colspan="2">Employment history confirmed by (Verifier Use Only):<input name="emploment_history_confirm_verify_use[]" type="text" class="form-control"/></td></tr>
                <tr><td>Signature:<input name="signature[]" type="text" class="form-control"/></td>
                <td>Date/Time:<input name="signature_datetime[]" type="text" class="form-control" /></td></tr>  
    </table>
</div>
<div class="delete">
    <a href="javascript:void(0);" class="btn red" id="delete">Delete</a>
</div>
  </div>  

 