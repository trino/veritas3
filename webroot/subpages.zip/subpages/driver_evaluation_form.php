                                                <div class="form-group">
													<label class="control-label col-md-3">Driver name <span class="required">
													* </span>
													</label>
													<div class="col-md-4">
														<input type="text" class="form-control" name=""/>
														
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-md-3">D/L# <span class="required">
													* </span>
													</label>
													<div class="col-md-4">
														<input type="text" placeholder="" class="form-control" name=""/>
														
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-md-3">Date <span class="required">
													* </span>
													</label>
													<div class="col-md-4">
														<input type="text" placeholder="" class="form-control date-picker" name=""/>
														
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-md-3">Transmission <span class="required">
													* </span>
													</label>
													<div class="col-md-4">
														<div class="checkbox-list">
															<label>
															<input type="checkbox" name="" value="1"/> Manual Shift </label>
															<label>
															<input type="checkbox" name="" value="2"/> Auto Shift </label>
														</div>
														<div id="form_payment_error">
														</div>
													</div>
												</div>
                                                <div class="form-group">
													<label class="control-label col-md-3">Name of evaluator <span class="required">
													* </span>
													</label>
													<div class="col-md-4">
														<input type="text" placeholder="" class="form-control" name=""/>														
													</div>
												</div>
                                                
                                                <div class="form-group">
													<label class="control-label col-md-3">Select <span class="required">
													* </span>
													</label>
													<div class="col-md-9">
														<div class="checkbox-list col-md-4 nopad">
															<label>
															<input type="checkbox" name="" value="1"/> Pre Hire </label>
															<label>
															<input type="checkbox" name="" value="2"/> Post Accident </label>
														</div>
														<div class="checkbox-list col-md-4 nopad">
															<label>
															<input type="checkbox" name="" value="1"/> Post Injury </label>
															<label>
															<input type="checkbox" name="" value="2"/> Post Training </label>
														</div>
                                                        <div class="checkbox-list col-md-4 nopad">
															<label>
															<input type="checkbox" name="" value="1"/> Annual </label>
															<label>
															<input type="checkbox" name="" value="2"/> Skill Verification </label>
														</div>
													</div>
												</div>
                                                <hr />
                                                
                                                <div class="col-md-12">
                                                    <div class="col-md-6">
                                                        <div class="portlet box blue">
                                                            <div class="portlet-title">
                                                                <div class="caption"><strong>Pre-trip Inspection:</strong> Fails to check the following</div>
                                                            </div>
                                                            
                                                            <div class="portlet-body">
                                                                <div class="col-md-6 checkbox-list">
                                                                    <label>
        															<input type="checkbox" name=""/> Fuel tank </label>
        															<label>
        															<input type="checkbox" name=""/> All Gauges </label>
                                                                    <label>
        															<input type="checkbox" name=""/> Audible Air Leaks </label>
        															<label>
        															<input type="checkbox" name=""/> Wheels Tires </label>
                                                                    <label>
        															<input type="checkbox" name=""/> Trailer Brakes </label>
                                                                    <label>
        															<input type="checkbox" name=""/> Trailer Airlines </label>
                                                                    <label>
        															<input type="checkbox" name=""/> Inspect 5th Wheel </label>
                                                                    <label>
        															<input type="checkbox" name=""/> Cold Check </label>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label>
        															<input type="checkbox" name=""/> Seat and Mirror set up </label>
        															<label>
        															<input type="checkbox" name=""/> Coupling&nbsp; &nbsp; &nbsp; &nbsp;</label>
                                                                    <label>
        															<input type="checkbox" name=""/> Paperwork </label>
        															<label>
        															<input type="checkbox" name=""/> Lights/ABS Lamps </label>
                                                                    <label>
        															<input type="checkbox" name=""/> Annual Inspection Stickers </label>
                                                                    <label>
        															<input type="checkbox" name=""/> In cab air brake checks </label>
                                                                    <label>
        															<input type="checkbox" name=""/> Landing Gear </label>
                                                                    <label>
        															<input type="checkbox" name=""/> Emergency exit </label>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="portlet box blue">
                                                            <div class="portlet-title">
                                                                <div class="caption"><strong>Driving:</strong></div>
                                                            </div>
                                                            
                                                            <div class="portlet-body">
                                                                <div>
                                                                    <div class="col-md-8">
            															Follows too closely 
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div> 
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Improper choice of Lane 
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Fails to use mirrors properly 
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>  
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Signal: wrong / late / not used / not cancelled
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>  
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Fails to use caution at R.R. Xing	
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                                
                                                                 <div>
                                                                    <div class="col-md-8">
            															Speed: too fast / too slow  	
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div> 
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Incorrect use of: clutch / brakes		
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Accelerator / gears / steering		
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Incorrect observation skills	
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Doesn't respond to instruction	
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                                
                                                <div class="col-md-12">
                                                    <div class="col-md-6">
                                                        <div class="portlet box blue">
                                                            <div class="portlet-title">
                                                                <div class="caption"><strong>Cornering:</strong></div>
                                                            </div>
                                                            
                                                            <div class="portlet-body">
                                                                <div>
                                                                    <div class="col-md-8">
            															Signaling: not used / late / not cancelled             
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div> 
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															  Speed:  too fast / too slow/momentum 
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Fails to get into proper:   lane / late / position
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>  
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Proper set up for turn  
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>  
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Turns too: wide / cuts corner / jumps curb          	
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                                
                                                                 <div>
                                                                    <div class="col-md-8">
            															Use of wrong lane / impede traffic 	
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div> 
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="portlet box blue">
                                                            <div class="portlet-title">
                                                                <div class="caption"><strong>Shifting:</strong> Fails to perform the following</div>
                                                            </div>
                                                            
                                                            <div class="portlet-body">
                                                                <div>
                                                                    <div class="col-md-8">
            															Smooth take off's           
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div> 
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															  Proper gear selection
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Proper clutching
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>  
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Gear recovery
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>  
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Up/down shifting         	
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                                
                                                                 
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                                <div class="col-md-12">
                                                    <div class="col-md-6">
                                                        <div class="portlet box blue">
                                                            <div class="portlet-title">
                                                                <div class="caption"><strong>Backing:</strong> sight side / blind side | <em>Fails to</em></div>
                                                            </div>
                                                            
                                                            <div class="portlet-body">
                                                                <div>
                                                                    <div class="col-md-8">
            															Uses proper set up          
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div> 
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															  Check vehicle path before / while backing           
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Use of 4 way flashers / city horn
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>  
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Shows certainty while steering
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>  
                                                                
                                                                <div>
                                                                    <div class="col-md-8">
            															Continually uses mirrors        	
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/> <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                                <div>
                                                                    <div class="col-md-8">
            															Maintain proper speed	       	
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                                <div>
                                                                    <div class="col-md-8">
            															Complete in a reasonable time and fashion	       	
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <input type="radio" name=""/>
                                                                    </div>
    							                                    <div class="clearfix"></div>
                                                                </div>
                                                                
                                                                 
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                                <hr />
                                                <div class="form-group">
													<label class="control-label col-md-3">Total score<span class="required">
													* </span>
													</label>
													<div class="col-md-4">
														<input type="text" class="form-control" name="" disabled="" value="24"/>
														
													</div>
												</div>
                                                <div class="form-group">
													<label class="control-label col-md-3">Auto shift<span class="required">
													* </span>
													</label>
													<div class="col-md-4">
														<input type="text" class="form-control" name=""/>
														
													</div>
												</div>
                                                <div class="form-group">
													<label class="control-label col-md-3">Manual<span class="required">
													* </span>
													</label>
													<div class="col-md-4">
														<input type="text" class="form-control" name=""/>
														
													</div>
												</div>
                                                <hr />
                                                <div class="form-group">
													<p class="center col-md-12 fontRed">The total score must be less than 20 to pass for Autoshift and 24 for Manual. Pass for a full trainee is less than 30</p>
												</div>
                                                <hr />
                                                <div class="form-group">
                                                    <p class="control-label col-md-3"><strong>Summary</strong></p>
                                                </div>
                                                <div class="form-group">
													<label class="control-label col-md-3">Recommended for hire <span class="required">
													* </span>
													</label>
													<div class="col-md-4">
														<div class="checkbox-list">
															<label>
															<input type="radio" name="" value="1"/> Yes </label>
															<label>
															<input type="radio" name="" value="0"/> No </label>
														</div>
														<div id="form_payment_error">
														</div>
													</div>
												</div>
                                                <div class="form-group">
													<label class="control-label col-md-3">Recommended as Full trainee <span class="required">
													* </span>
													</label>
													<div class="col-md-4">
														<div class="checkbox-list">
															<label>
															<input type="radio" name="" value="1"/> Yes </label>
															<label>
															<input type="radio" name="" value="0"/> No </label>
														</div>
														<div id="form_payment_error">
														</div>
													</div>
												</div>
                                                <div class="form-group">
													<label class="control-label col-md-3">Recommended fire hire with trainee <span class="required">
													* </span>
													</label>
													<div class="col-md-4">
														<div class="checkbox-list">
															<label>
															<input type="radio" name="" value="1"/> Yes </label>
															<label>
															<input type="radio" name="" value="0"/> No </label>
														</div>
														<div id="form_payment_error">
														</div>
													</div>
												</div>
                                                
                                                <div class="form-group">
													<label class="control-label col-md-3">Comments <span class="required">
													* </span>
													</label>
													<div class="col-md-4">
														<textarea  placeholder="" class="form-control" name=""></textarea>
														
													</div>
												</div>
                                                <div class="clearfix"></div>
                                                
                                                <div class="form-group col-md-12">
                                                    <label class="control-label col-md-6">Attach Files : </label>
                                                    <div class="col-md-6">
                                                    <a href="javascript:void(0);" class="btn btn-primary">Browse</a>
                                                    </div>
                                                   </div>
                                                   
                                                  <div class="form-group col-md-12">
                                                    <div id="more_driver_doc">
                                                    </div>
                                                    <div class="col-md-6">
                                                    </div>
                                                  </div>
                                                  
                                                  <div class="form-group col-md-12">
                                                    <div class="col-md-6">
                                                    </div>
                                                    <div class="col-md-6">
                                                        <a href="javascript:void(0);" class="btn btn-success" id="add_more_driver_doc">Add More</a>
                                                    </div>
                                                  </div>
                                                  
                                                  
                                                    
                                                    <div class="clearfix"></div>
 <script>
    $(function(){
       $('#add_more_driver_doc').click(function(){
        $('#more_driver_doc').append('<div class="del_append_driver"><label class="control-label col-md-6">Attach File : </label><div class="col-md-6 pad_bot"><a href="javascript:void(0);" class="btn btn-primary">Browse</a><a  href="javascript:void(0);" class="btn btn-danger" id="delete_driver_doc">Delete</a></div></div>')
       }); 
       
       $('#delete_driver_doc').live('click',function(){
            $(this).closest('.del_append_driver').remove();
       });
       
        //$("#test2").jqScribble();
    });
    	
</script>                                               